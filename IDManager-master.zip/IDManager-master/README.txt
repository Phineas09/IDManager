Server-Side:
	- readAndCheck.php
	- Mailing.xaml (UiPath Studio app)
	- Google_Orc.exe
	- Token.exe
		
Client-Side:
	-upload.php
	
How to use:
1)	The server-side opens Mailing.xaml and runs it.
2)	The server-side opens readAndCheck.php which checks the database for inconsistencies and sends mail adresses to Mailing.xaml
3)	If the user has an expired ID, he/she will recieve an E-Mail to send the new ID card.
4)  The user uploads a photo of his/her ID card.
5)	The server-side updates the database.