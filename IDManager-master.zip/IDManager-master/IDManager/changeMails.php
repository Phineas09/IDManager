<?php // txt numit format.txt
  // apelez scriptul
  $fin = fopen("out.txt", "r") or die("Unable to open file!");

  // date database
  $dbServername = '192.168.43.111:80';
  $dbAdmin = 'root';
  $dbPassword = '';
  $dbName = 'bcr_db';
  //

$conn = mysqli_connect($dbServername,$dbAdmin,$dbPassword,$dbName);

// am nevoie de un array in care voi stoca cele 7 date ale clientului din poza
$dateClient = array();
for($i = 0; $i < 7; $i++)
{
  $line = fgets($fin);
  array_push($dateClient, $line);
}

fclose($fin);
// Voi citi din fisier cu array_push($dateClient, $line);
//
  $tableColumns = array(
    0 => "Nume",
    1 => "Prenume",
    2 => "Serie",
    3 => "Nr_Serie",
    4 => "CNP",
    5 => "Cetatenie",
    6 => "Data_Expirare",
	7 => "E-Mail"
  );

    $sqlcode = "SELECT ".$tableColumns[6]." FROM clienti;";
    $result = mysqli_query($conn,$sqlcode);

function Aexpirat($datetocheck){
	$zi=intval( $datetocheck[0].$datetocheck[1]);
	$luna=intval( $datetocheck[3] .$datetocheck[4]);
	$an=intval( $datetocheck[6] .$datetocheck[7] .$datetocheck[8] .$datetocheck[9]);
	$datacurenta=date("d.m.Y");
	if(intval( $datacurenta[6] .$datacurenta[7] .$datacurenta[8] .$datacurenta[9])>$an)
		return true;
	else
		if(intval( $datacurenta[6] .$datacurenta[7] .$datacurenta[8] .$datacurenta[9])==$an)
			if(intval( $datacurenta[3] .$datacurenta[4])>$luna)
				return true;
			else
				if(intval( $datacurenta[3] .$datacurenta[4])==$luna)
					if(intval( $datacurenta[0] .$datacurenta[1])>$zi)
						return true;
	return false;
}

$vector  = array();

    while($row = mysqli_fetch_assoc($result)){
  		if(Aexpirat($row[6])){
			array_push($vector, $row[7]);
		//	file_put_contents ( "mailuri.txt" , mixed $row[7] );
  		}
    }






?>
