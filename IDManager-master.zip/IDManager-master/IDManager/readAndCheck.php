<?php // txt numit format.txt
  // apelez scriptul
  $rel = 'Google_Orc.exe';
  $abs = realpath($rel);
  exec($rel);

Sleep(4);

  $fin = fopen("out.txt", "r") or die("Unable to open file!");

  // date database
  $dbServername = 'localhost';
  $dbAdmin = 'root';
  $dbPassword = '';
  $dbName = 'bcr_db';
  //

$conn = mysqli_connect($dbServername,$dbAdmin,$dbPassword,$dbName);

// am nevoie de un array in care voi stoca cele 7 date ale clientului din poza
$dateClient = array();
for($i = 0; $i < 7; $i++)
{
  $line = fgets($fin);
  $nonewline = rtrim($line,"\n\r ");
  array_push($dateClient, $nonewline);
}

fclose($fin);
// Voi citi din fisier cu array_push($dateClient, $line);
//
  $tableColumns = array(
    0 => "Nume",
    1 => "Prenume",
    2 => "Serie",
    3 => "Nr_Serie",
    4 => "CNP",
    5 => "Cetatenie",
    6 => "Data_Expirare",
    7 => "E-Mail"
  );
function Aexpirat($datetocheck){
	$zi=intval( $datetocheck[0].$datetocheck[1]);
	$luna=intval( $datetocheck[3] .$datetocheck[4]);
	$an=intval( $datetocheck[6] .$datetocheck[7] .$datetocheck[8] .$datetocheck[9]);
	$datacurenta=date("d.m.Y");
	if(intval( $datacurenta[6] .$datacurenta[7] .$datacurenta[8] .$datacurenta[9])>$an)
		return true;
	else
		if(intval( $datacurenta[6] .$datacurenta[7] .$datacurenta[8] .$datacurenta[9])==$an)
			if(intval( $datacurenta[3] .$datacurenta[4])>$luna)
				return true;
			else
				if(intval( $datacurenta[3] .$datacurenta[4])==$luna)
					if(intval( $datacurenta[0] .$datacurenta[1])>$zi)
						return true;
	return false;
}

$vector  = array();
$sqlcode = "SELECT * FROM clienti";
$result = mysqli_query($conn,$sqlcode);

    while($row = mysqli_fetch_assoc($result)){
  		if(Aexpirat($row[$tableColumns[6]])){
        echo "Am expirat".$row[$tableColumns[6]]." ".$row[$tableColumns[7]];
			//array_push($vector, $row[7]);
			file_put_contents ( "mailuri.txt" , $row[$tableColumns[7]] );
  		}
    }

// aici incepe interogarea


?>
