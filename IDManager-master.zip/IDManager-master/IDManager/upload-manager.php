<?php

$target_dir = "uploads/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
    if($check !== false) {
        echo "Imaginea a fost incarcata cu succes! Va multumim!";
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }
}

move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], "image.jpeg");


$rel = 'Google_Orc.exe';
exec($rel);

echo "<br />";
echo "Veti fi redirectionat...";

Sleep(4);

$fin = fopen("out.txt", "r") or die("Unable to open file!");

// date database
$dbServername = 'localhost';
$dbAdmin = 'root';
$dbPassword = '';
$dbName = 'bcr_db';
//

$conn = mysqli_connect($dbServername,$dbAdmin,$dbPassword,$dbName);

// am nevoie de un array in care voi stoca cele 7 date ale clientului din poza
$dateClient = array();
for($i = 0; $i < 7; $i++)
{
$line = fgets($fin);
$nonewline = rtrim($line,"\n\r ");
array_push($dateClient, $nonewline);
}

fclose($fin);
// Voi citi din fisier cu array_push($dateClient, $line);
//
$tableColumns = array(
  0 => "Nume",
  1 => "Prenume",
  2 => "Serie",
  3 => "Nr_Serie",
  4 => "CNP",
  5 => "Cetatenie",
  6 => "Data_Expirare",
  7 => "E-Mail"
);

for($i = 0; $i < 7; $i++)
{

  $sqlcode = "SELECT ".$tableColumns[$i]." FROM clienti";
  $result = mysqli_query($conn,$sqlcode);

  while($row = mysqli_fetch_assoc($result)){
    if($i != 2 && $i != 3 && $i != 6){
    if((string)$row[$tableColumns[$i]] == (string)$dateClient[$i]) // daca nu e serie, nr serie sau data
  {
    $bool = true;
    break;
  }
    else {
      $bool = false;
      break;
    }
  }
}
}

if($bool === true ){ // daca
  // pot updata baza de date
  $sqlcode = "UPDATE clienti SET Serie = "."\"".$dateClient[2]."\"".", Nr_Serie = "."\"".$dateClient[3]."\"".", Data_Expirare = "."\"".$dateClient[6]."\""." WHERE CNP = "."\"".$dateClient[4]."\"";
  mysqli_query($conn,$sqlcode);
}

function Redirect($url, $permanent = false)
{
    header('Location: ' . $url, true, $permanent ? 301 : 302);

    exit();
}

Sleep(5);
Redirect('http://bcr.ro/', false);
?>
